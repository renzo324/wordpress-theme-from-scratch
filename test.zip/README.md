# wordpress-theme-from-scratch
making a wordpress theme from scratch and hopefully get it approved
