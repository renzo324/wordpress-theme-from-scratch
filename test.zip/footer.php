    <div id="sub-footer">
        <div class="container">
            <div id="sub-content">
                <div class="row">
                    
                    <?php dynamic_sidebar('footer-widgets-3'); ?> 
                </div>
            </div>
        </div>
    </div>
    <?php wp_footer(); ?> 
</body>

</html>